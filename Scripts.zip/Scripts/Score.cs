﻿using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    [SerializeField] public Player player;
    public int score;
    public Text scoreText;

    // Update is called once per frame
    void Update()
    {
        score = player.GetCollectible();
        scoreText.text = score.ToString();

    }
}
