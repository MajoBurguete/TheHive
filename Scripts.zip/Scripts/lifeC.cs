﻿using UnityEngine;
using UnityEngine.UI;

public class lifeC : MonoBehaviour
{
   [SerializeField] public Player player;
    public int counter;
    public Text counterText;

    // Update is called once per frame
    void Update()
    {
        counter = player.GetLife();
        counterText.text = counter.ToString();

    }
}
