﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;  //Le dice a unity que namespace usar

public class Player : MonoBehaviour
{
    [SerializeField] private Transform groundCheckTransform = null;
    [SerializeField] private LayerMask playerMask;
    [SerializeField] private int collectibles;

    private bool jumpKeyWasPressed;
    private float horizontalInput;

    private Rigidbody rigidbodyComponent;
    private int superJumpRemaining;
    
    private int lifeCounter;
    private Vector3 originalPos;



    


    // Start is called before the first frame update
    void Start()
    {
        rigidbodyComponent = GetComponent<Rigidbody>();
        originalPos = new Vector3(transform.position.x, transform.position.y, transform.position.z);

    }

    // Update is called once per frame
    void Update()
    {
        //Checa si la tecla espacio esta presionada (pressed down)

    
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpKeyWasPressed=true;
        }

        horizontalInput = Input.GetAxis("Horizontal");

        if (transform.position.y < -20)
        {
            transform.position = originalPos;
            lifeCounter++;
        } 

        if ((transform.position.x > 150)&&(transform.position.y > 57))
        {
            rigidbodyComponent.constraints = RigidbodyConstraints.FreezePosition;
        } 
        
    } 

    //FixedUpdate is called once every physic update
    private void FixedUpdate()
    {
         rigidbodyComponent.velocity = new Vector3(horizontalInput * 4, rigidbodyComponent.velocity.y, 0);

         if(Physics.OverlapSphere(groundCheckTransform.position, 0.1f, playerMask).Length == 0)
         {
            return;
         }

         if (jumpKeyWasPressed == true)
        {
            float jumpPower = 10f;
            if (superJumpRemaining > 0)
            {
                jumpPower *= 2.5f;
                superJumpRemaining --;
            }
            rigidbodyComponent.AddForce(Vector3.up * jumpPower, ForceMode.VelocityChange);
            jumpKeyWasPressed = false;
        }   

    }

    private void OnTriggerEnter(Collider other) {
        if (other.gameObject.layer == 9){
            Destroy(other.gameObject);
            collectibles++;
        }
        if (other.gameObject.layer == 10){
            Destroy(other.gameObject);
            superJumpRemaining++;
        }
    }

    public int GetCollectible(){
        return collectibles;
    }

    public int GetLife(){
        return lifeCounter;
    }

}
